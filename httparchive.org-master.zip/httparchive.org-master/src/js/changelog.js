export default class Changelog {

	static get URL() {
		return 'https://cdn.rawgit.com/HTTPArchive/httparchive/master/docs/changelog.json';
	}

}
