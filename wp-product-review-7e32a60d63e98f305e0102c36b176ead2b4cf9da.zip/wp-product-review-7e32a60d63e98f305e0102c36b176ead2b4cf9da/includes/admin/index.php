<?php
/**
 * Silence is golden
 *
 * @package     WPPR
 * @copyright   Copyright (c) 2017, Bogdan Preda
 * @license     http://opensource.org/licenses/gpl-2.0.php GNU Public License
 * @since       3.0.0
 */

/**
 * Nothing to do here.
 */
